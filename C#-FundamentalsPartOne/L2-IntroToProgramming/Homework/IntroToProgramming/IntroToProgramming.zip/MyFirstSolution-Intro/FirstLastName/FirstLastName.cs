﻿using System;

class FirstLastName
{
    /// <summary>
    /// Exercise 6
    ///     Create console application that prints your first and last name.
    /// </summary>
    static void Main()
    {
        Console.WriteLine("My first name is \"Jane\" and my last is \"Doe\".");
    }
}
