﻿using System;

class HelloCSharp
{
    /// <summary>
    /// Exercises 2 & 3
    ///     Create, compile and run a “Hello C#” console application.
    ///     Modify the application to print your name.
    /// </summary>
    static void Main()
    {
        Console.WriteLine("My name is \"Jane Doe\" "); // original was: Console.WriteLine("Hello C#");
    }
}
