﻿using System;

class PrintNumbers
{
    /// <summary>
    /// Exercise 4
    ///     Write a program to print the numbers 1, 101 and 1001.
    /// </summary>
    static void Main()
    {
        Console.WriteLine("Numbers 1, 101 and 1001.");
        
        //another solution
        Console.WriteLine("Numbers {0}, {1} and {2}.", 1, 101, 1001);
    }
}